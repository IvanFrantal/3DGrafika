Compile with:
g++ -std=c++17 containers.cpp ext/*.c -I./include -L./lib -lglfw3dll -o out.exe

g++ -std=c++17 main.cpp ext/*.c -I./include -L./lib -lglfw3dll -o out.exe